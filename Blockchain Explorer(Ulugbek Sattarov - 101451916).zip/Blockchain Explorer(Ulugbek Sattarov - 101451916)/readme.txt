ULUGBEK SATTAROV - 101451916

backend Set Up
Run "npm install" 
Run "npm run start" 

 frontend Set Up
Run "npm install" 
Run "npm run start" 
const express = require("express");
const transactionController = require("../transactionController");
const transactionRouter = express.Router();
const addressHistory = "/history"
const amount = "/receipt/amount"

transactionRouter.get(addressHistory, transactionController.transactionHistory);

transactionRouter.post(
  amount,
  transactionController.transactionReceipt
);
module.exports = transactionRouter;

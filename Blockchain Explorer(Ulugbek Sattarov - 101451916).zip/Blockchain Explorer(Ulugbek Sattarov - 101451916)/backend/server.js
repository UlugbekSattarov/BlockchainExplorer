const dotenv = require("dotenv");
dotenv.config();
const PORT = process.env.PORT;
const express = require("express");
const ethAddressesRouter = require(".AddressesRoute");
const connection = require("./DBConnection");
const transactionRouter = require("./tranactionRoutes");
const app = express();

app.use(express.json());

app.use("/api/addresses", ethAddressesRouter);
app.use("/api/tranaction", transactionRouter);

app.get("/", (req, res) => {
  res.send("Successfully deployed");
});

app.listen(PORT, () => {
  connection();
  console.log(`Server is Running on ${PORT}!`);
});

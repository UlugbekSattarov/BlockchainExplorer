const addresses = [
    "0x1111111254EEB25477B68fB85Ed929f7A3960582",
    // ... (other addresses)
    "0x66cB9c977E13Df9b0de53b25152280BB72383700",
  ];
  
  const getAddresses = () => {
    return addresses;
  };
  
  module.exports = { getAddresses };
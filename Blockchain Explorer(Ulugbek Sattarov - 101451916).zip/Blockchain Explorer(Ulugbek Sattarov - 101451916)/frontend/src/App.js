// src/App.jsx
import React from 'react';
import AddressesComponent from './components/AddressesComponent';

function App() {
  return (
    <div className="App">
      <h1>Addresses</h1>
      <AddressesComponent />
    </div>
  );
}

export default App;


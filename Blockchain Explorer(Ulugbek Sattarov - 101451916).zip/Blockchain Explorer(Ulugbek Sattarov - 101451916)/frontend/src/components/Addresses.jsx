// src/components/AddressesComponent.jsx
import React, { useEffect, useState } from 'react';

function AddressesComponent() {
  const [addresses, setAddresses] = useState([]);

  useEffect(() => {
    // Replace 'http://localhost:3000' with the address of your backend server if it's different
    fetch('http://localhost:3000/account/addresses')
      .then(response => response.json())
      .then(data => setAddresses(data))
      .catch(error => console.error('Error fetching addresses:', error));
  }, []);

  return (
    <ul>
      {addresses.map((address, index) => (
        <li key={index}>{address}</li>
      ))}
    </ul>
  );
}

export default AddressesComponent;
